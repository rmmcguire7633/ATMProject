CREATE VIEW [Totals] AS SELECT SUM(Account.balance) FROM Account GROUP BY bank_id;

